﻿using Mandatory2DGameFramework.worlds;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandatory2DGameFramework.worlds
{/// <summary>
 /// Repræsenterer spillets verden, som består af skabninger og objekter.
 /// </summary>
    public class World
    {
        /// <summary>
        /// Den maksimale værdi for X-koordinaten i verdenen.
        /// </summary>
        public int MaxX { get; set; }

        /// <summary>
        /// Den maksimale værdi for Y-koordinaten i verdenen.
        /// </summary>
        public int MaxY { get; set; }

        /// <summary>
        /// Listen over skabninger, der findes i verdenen.
        /// </summary>
        public List<Creature> Creatures { get; set; }

        /// <summary>
        /// Listen over objekter, der findes i verdenen.
        /// </summary>
        public List<WorldObject> WorldObjects { get; set; }

        /// <summary>
        /// Initialiserer en ny instans af <see cref="World"/>-klassen med specifikke dimensioner.
        /// </summary>
        /// <param name="maxX">Den maksimale værdi for X-koordinaten i verdenen.</param>
        /// <param name="maxY">Den maksimale værdi for Y-koordinaten i verdenen.</param>
        public World(int maxX, int maxY)
        {
            MaxX = maxX;
            MaxY = maxY;
            Creatures = new List<Creature>();
            WorldObjects = new List<WorldObject>();
        }

        /// <summary>
        /// Tilføjer en skabning til verdenen.
        /// </summary>
        /// <param name="creature">Den skabning, der skal tilføjes.</param>
        public void AddCreature(Creature creature)
        {
            Creatures.Add(creature);
        }

        /// <summary>
        /// Tilføjer et objekt til verdenen.
        /// </summary>
        /// <param name="worldObject">Det objekt, der skal tilføjes.</param>
        public void AddWorldObject(WorldObject worldObject)
        {
            WorldObjects.Add(worldObject);
        }
    }
}