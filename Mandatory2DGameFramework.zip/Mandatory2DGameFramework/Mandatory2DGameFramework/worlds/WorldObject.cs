﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandatory2DGameFramework.worlds
{
    /// <summary>
    /// Repræsenterer et objekt i verdenen, som kan være en del af spillets miljø.
    /// Objekter kan være lootable eller removable afhængigt af deres egenskaber.
    /// </summary>
    public class WorldObject
    {
        /// <summary>
        /// Navnet på objektet.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Angiver, om objektet kan samles op af skabninger.
        /// </summary>
        public bool Lootable { get; set; }

        /// <summary>
        /// Angiver, om objektet kan fjernes fra verdenen.
        /// </summary>
        public bool Removable { get; set; }

        /// <summary>
        /// Initialiserer en ny instans af <see cref="WorldObject"/>-klassen.
        /// </summary>
        /// <param name="name">Navnet på objektet.</param>
        /// <param name="lootable">Angiver, om objektet kan samles op.</param>
        /// <param name="removable">Angiver, om objektet kan fjernes fra verdenen.</param>
        public WorldObject(string name, bool lootable, bool removable)
        {
            Name = name;
            Lootable = lootable;
            Removable = removable;
        }
    }
}
