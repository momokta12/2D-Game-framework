﻿using Mandatory2DGameFramework.worlds;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandatory2DGameFramework.model.defence
{
    /// <summary>
    /// Repræsenterer et forsvarsobjekt, som en skabning kan bruge til at reducere skader fra angreb.
    /// </summary>
    public class DefenceItem : WorldObject
    {
        /// <summary>
        /// Mængden af skade, som dette forsvarsobjekt reducerer.
        /// </summary>
        public int ReduceHitPoint { get; set; }

        /// <summary>
        /// Initialiserer en ny instans af <see cref="DefenceItem"/>-klassen.
        /// </summary>
        /// <param name="name">Navnet på forsvarsobjektet.</param>
        /// <param name="reduceHitPoint">Mængden af skade, som dette forsvarsobjekt reducerer.</param>
        public DefenceItem(string name, int reduceHitPoint)
            : base(name, true, true)
        {
            ReduceHitPoint = reduceHitPoint;
        }
    }
}
