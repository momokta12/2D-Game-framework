﻿using Mandatory2DGameFramework.model.attack;
using Mandatory2DGameFramework.model.defence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandatory2DGameFramework.model.Cretures
{
    /// <summary>
    /// Definerer de forskellige typer af skabninger, der kan oprettes.
    /// </summary>
    public enum CreatureType
    {
        /// <summary>
        /// Drage - En kraftig skabning med høj livspoint og kraftige angreb.
        /// </summary>
        Dragon,

        /// <summary>
        /// Ridder - En stærk skabning med godt forsvar og en god balance mellem angreb og forsvar.
        /// </summary>
        Knight,

        /// <summary>
        /// Troldmand - En skabning med magiske angreb, men med lavere livspoint.
        /// </summary>
        Wizard,
    }

    /// <summary>
    /// En fabriksmetode til at oprette forskellige typer af skabninger.
    /// </summary>
    public static class CreatureFactory
    {
        /// <summary>
        /// Opretter en skabning baseret på den angivne type.
        /// </summary>
        /// <param name="type">Typen af skabning, der skal oprettes.</param>
        /// <returns>En instans af skabningen baseret på den angivne type.</returns>
        /// <exception cref="ArgumentException">Kastes, hvis skabningstypen ikke genkendes.</exception>
        public static Creature CreateCreature(CreatureType type)
        {
            switch (type)
            {
                case CreatureType.Dragon:
                    return new Creature("Dragon", 150)
                    {
                        AttackItems = new List<AttackItem> { new AttackItem("Fire Breath", 30, 5) },
                        DefenceItems = new List<DefenceItem> { new DefenceItem("Dragon Scales", 20) }
                    };
                case CreatureType.Knight:
                    return new Creature("Knight", 100)
                    {
                        AttackItems = new List<AttackItem> { new AttackItem("Sword", 20, 1) },
                        DefenceItems = new List<DefenceItem> { new DefenceItem("Shield", 15) }
                    };
                case CreatureType.Wizard:
                    return new Creature("Wizard", 50)
                    {
                        AttackItems = new List<AttackItem> { new AttackItem("Summons of destruction", 10, 1) },
                        DefenceItems = new List<DefenceItem> { new DefenceItem("Teleport potion", 5) }
                    };
                default:
                    throw new ArgumentException("Unknown creature type");
            }
        }
    }
}
