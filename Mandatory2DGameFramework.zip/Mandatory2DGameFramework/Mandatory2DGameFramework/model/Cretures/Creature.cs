﻿using Mandatory2DGameFramework.model.attack;
using Mandatory2DGameFramework.model.defence;
using Mandatory2DGameFramework.worlds;
using Mandatory2DGameFramework.model.Logger;
using Mandatory2DGameFramework.ICreatureState;// Namespace for ICreatureState
using Mandatory2DGameFramework.ICreatureComponent;// Namespace for ICreatureComponent
using System;
using System.Collections.Generic;
using System.Linq;
using Mandatory2DGameFramework.ICreatureComponent;
using Mandatory2DGameFramework.ICreatureState.cs;

public class Creature : WorldObject, ICreatureComponent
{
    /// <summary>
    /// Livspoint for skabningen.
    /// </summary>
    public int HitPoint { get; set; }

    /// <summary>
    /// Liste over angrebsobjekter (våben), som skabningen har.
    /// </summary>
    public List<AttackItem> AttackItems { get; set; }

    /// <summary>
    /// Liste over forsvarsobjekter (rustning), som skabningen har.
    /// </summary>
    public List<DefenceItem> DefenceItems { get; set; }

    /// <summary>
    /// X-koordinat for skabningens position i verdenen.
    /// </summary>
    public int X { get; set; }

    /// <summary>
    /// Y-koordinat for skabningens position i verdenen.
    /// </summary>
    public int Y { get; set; }

    /// <summary>
    /// Skabningens nuværende tilstand (f.eks. normal, rasende, svækket).
    /// </summary>
    public ICreatureState CurrentState { get; private set; }

    /// <summary>
    /// Initialiserer en ny instans af <see cref="Creature"/>-klassen.
    /// </summary>
    /// <param name="name">Navnet på skabningen.</param>
    /// <param name="hitPoint">Livspoint for skabningen.</param>
    /// <param name="startX">Startpositionens X-koordinat.</param>
    /// <param name="startY">Startpositionens Y-koordinat.</param>
    public Creature(string name, int hitPoint, int startX = 0, int startY = 0)
        : base(name, true, true)
    {
        HitPoint = hitPoint;
        AttackItems = new List<AttackItem>();
        DefenceItems = new List<DefenceItem>();
        X = startX;
        Y = startY;
        CurrentState = new NormalState();
    }

    /// <summary>
    /// Skifter skabningens tilstand til en ny tilstand.
    /// </summary>
    /// <param name="newState">Den nye tilstand, skabningen skal skifte til.</param>
    public void ChangeState(ICreatureState newState)
    {
        CurrentState = newState;
        CurrentState.Handle(this);
    }

    /// <summary>
    /// Bevæger skabningen til en ny position i verdenen.
    /// </summary>
    /// <param name="deltaX">Ændring i X-koordinaten.</param>
    /// <param name="deltaY">Ændring i Y-koordinaten.</param>
    /// <param name="maxX">Den maksimale X-værdi for verdenen.</param>
    /// <param name="maxY">Den maksimale Y-værdi for verdenen.</param>
    public void Move(int deltaX, int deltaY, int maxX, int maxY)
    {
        int newX = X + deltaX;
        int newY = Y + deltaY;

        if (newX >= 0 && newX < maxX && newY >= 0 && newY < maxY)
        {
            X = newX;
            Y = newY;
            MyLogger.Instance.Log($"{Name} bevæger sig til position ({X}, {Y}).");
        }
        else
        {
            MyLogger.Instance.Log($"{Name} kan ikke bevæge sig uden for verdens grænser.");
        }
    }

    /// <summary>
    /// Angriber en anden skabning eller komponent.
    /// </summary>
    /// <param name="target">Målet, der skal angribes.</param>
    public void Hit(ICreatureComponent target)
    {
        if (AttackItems.Count == 0)
        {
            MyLogger.Instance.Log($"{Name} har ingen våben og kan ikke angribe.");
            return;
        }

        int baseDamage = AttackItems.Sum(attack => attack.Hit);
        int totalDamage = CurrentState.CalculateDamage(baseDamage);
        MyLogger.Instance.Log($"{Name} angriber {target.GetType().Name} og gør {totalDamage} skade.");
        target.ReceiveHit(totalDamage);
    }

    /// <summary>
    /// Modtager skade fra et angreb.
    /// </summary>
    /// <param name="incomingHit">Mængden af skade, der modtages.</param>
    public void ReceiveHit(int incomingHit)
    {
        int totalReduction = DefenceItems.Sum(defence => defence.ReduceHitPoint);
        int damageTaken = Math.Max(0, incomingHit - totalReduction);
        HitPoint -= damageTaken;

        MyLogger.Instance.Log($"{Name} modtager {damageTaken} skade og har nu {HitPoint} livspoint tilbage.");

        if (HitPoint <= 0)
        {
            MyLogger.Instance.Log($"{Name} er død.");
        }
    }

    /// <summary>
    /// Samler et objekt op fra verdenen.
    /// </summary>
    /// <param name="obj">Objektet, der skal samles op.</param>
    public void LootObject(WorldObject obj)
    {
        if (!obj.Lootable)
        {
            MyLogger.Instance.Log($"{Name} kan ikke samle {obj.Name} op.");
            return;
        }

        if (obj is AttackItem attackItem)
        {
            AttackItems.Add(attackItem);
            MyLogger.Instance.Log($"{Name} samler våbenet {attackItem.Name} op.");
        }
        else if (obj is DefenceItem defenceItem)
        {
            DefenceItems.Add(defenceItem);
            MyLogger.Instance.Log($"{Name} samler forsvarsobjektet {defenceItem.Name} op.");
        }
        else
        {
            MyLogger.Instance.Log($"{Name} kan ikke bruge {obj.Name}.");
        }
    }

    /// <summary>
    /// Viser information om skabningen.
    /// </summary>
    public void DisplayInfo()
    {
        Console.WriteLine($"Skabning: {Name}, Livspoint: {HitPoint}, Position: ({X}, {Y})");
    }
}
