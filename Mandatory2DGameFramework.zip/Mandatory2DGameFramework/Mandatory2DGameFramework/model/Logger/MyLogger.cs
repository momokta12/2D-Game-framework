﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandatory2DGameFramework.model.Logger
{
    /// <summary>
    /// En singleton-klasse til logging af beskeder i spillet.
    /// Bruges til at logge beskeder til forskellige lyttere (f.eks. konsollen eller en fil).
    /// </summary>
    public class MyLogger
    {
        private static MyLogger _instance;
        private List<TraceListener> _listeners;

        /// <summary>
        /// Privat konstruktør for at forhindre direkte instansiering. Initialiserer listen over lyttere.
        /// </summary>
        private MyLogger()
        {
            _listeners = new List<TraceListener>();
        }

        /// <summary>
        /// Får den eneste instans af <see cref="MyLogger"/> (singleton).
        /// </summary>
        public static MyLogger Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new MyLogger();
                return _instance;
            }
        }

        /// <summary>
        /// Tilføjer en lytter, som loggeren skal skrive beskeder til.
        /// </summary>
        /// <param name="listener">Lytteren, der skal tilføjes.</param>
        public void AddListener(TraceListener listener)
        {
            _listeners.Add(listener);
        }

        /// <summary>
        /// Fjerner en lytter, som loggeren skriver beskeder til.
        /// </summary>
        /// <param name="listener">Lytteren, der skal fjernes.</param>
        public void RemoveListener(TraceListener listener)
        {
            _listeners.Remove(listener);
        }

        /// <summary>
        /// Logger en besked ved at sende den til alle tilføjede lyttere.
        /// </summary>
        /// <param name="message">Beskeden, der skal logges.</param>
        public void Log(string message)
        {
            foreach (var listener in _listeners)
            {
                listener.WriteLine(message);
            }
        }
    }

    /// <summary>
    /// En konsol-lyttere, der logger beskeder til konsolvinduet.
    /// </summary>
    public class ConsoleTraceListener : TraceListener
    {
        /// <summary>
        /// Logger en besked til konsollen uden ny linje.
        /// </summary>
        /// <param name="message">Beskeden, der skal logges.</param>
        public override void Write(string message)
        {
            Console.Write(message);
        }

        /// <summary>
        /// Logger en besked til konsollen med ny linje.
        /// </summary>
        /// <param name="message">Beskeden, der skal logges.</param>
        public override void WriteLine(string message)
        {
            Console.WriteLine(message);
        }
    }
}
