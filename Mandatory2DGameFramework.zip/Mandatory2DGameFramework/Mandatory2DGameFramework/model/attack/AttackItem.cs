﻿using Mandatory2DGameFramework.worlds;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandatory2DGameFramework.model.attack
{
    /// <summary>
    /// Repræsenterer et angrebsobjekt, som en skabning kan bruge til at angribe andre skabninger.
    /// </summary>
    public class AttackItem : WorldObject
    {
        /// <summary>
        /// Mængden af skade, som dette angrebsobjekt påfører.
        /// </summary>
        public int Hit { get; set; }

        /// <summary>
        /// Rækkevidden af angrebet for dette angrebsobjekt.
        /// </summary>
        public int Range { get; set; }

        /// <summary>
        /// Initialiserer en ny instans af <see cref="AttackItem"/>-klassen.
        /// </summary>
        /// <param name="name">Navnet på angrebsobjektet.</param>
        /// <param name="hit">Mængden af skade, som dette angrebsobjekt påfører.</param>
        /// <param name="range">Rækkevidden af angrebet.</param>
        public AttackItem(string name, int hit, int range)
            : base(name, true, true)
        {
            Hit = hit;
            Range = range;
        }
    }
}
