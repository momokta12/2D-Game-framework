﻿using Mandatory2DGameFramework.model.attack;
using Mandatory2DGameFramework.model.defence;
using Mandatory2DGameFramework.worlds;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Mandatory2DGameFramework.XML
{
    /// <summary>
    /// Læser konfigurationer fra en XML-fil for at initialisere en verden med skabninger og objekter.
    /// </summary>
    public class ConfigReader
    {
        /// <summary>
        /// Indlæser en verden fra en XML-konfigurationsfil.
        /// </summary>
        /// <param name="filePath">Stien til XML-filen, der indeholder verdens konfigurationen.</param>
        /// <returns>En instans af <see cref="World"/>, initialiseret med data fra XML-filen.</returns>
        /// <exception cref="Exception">Kastes, hvis verdenen ikke kan indlæses fra XML-filen.</exception>
        public static World LoadWorldFromXml(string filePath)
        {
            var document = XDocument.Load(filePath);
            var worldElement = document.Element("GameConfig")?.Element("World");

            if (worldElement == null)
            {
                throw new Exception("Verdenen kunne ikke indlæses fra XML.");
            }

            int maxX = int.Parse(worldElement.Attribute("MaxX")?.Value ?? "0");
            int maxY = int.Parse(worldElement.Attribute("MaxY")?.Value ?? "0");
            World world = new World(maxX, maxY);

            // Indlæs skabninger
            var creatures = worldElement.Element("Creatures")?.Elements("Creature");
            if (creatures != null)
            {
                foreach (var creatureElement in creatures)
                {
                    string name = creatureElement.Attribute("Name")?.Value;
                    int hitPoint = int.Parse(creatureElement.Attribute("HitPoint")?.Value ?? "0");

                    Creature creature = new Creature(name, hitPoint);

                    // Indlæs angrebsobjekter
                    var attackItems = creatureElement.Element("AttackItems")?.Elements("AttackItem");
                    if (attackItems != null)
                    {
                        foreach (var attackItemElement in attackItems)
                        {
                            string attackName = attackItemElement.Attribute("Name")?.Value;
                            int hit = int.Parse(attackItemElement.Attribute("Hit")?.Value ?? "0");
                            int range = int.Parse(attackItemElement.Attribute("Range")?.Value ?? "0");

                            AttackItem attackItem = new AttackItem(attackName, hit, range);
                            creature.AttackItems.Add(attackItem);
                        }
                    }

                    // Indlæs forsvarsobjekter
                    var defenceItems = creatureElement.Element("DefenceItems")?.Elements("DefenceItem");
                    if (defenceItems != null)
                    {
                        foreach (var defenceItemElement in defenceItems)
                        {
                            string defenceName = defenceItemElement.Attribute("Name")?.Value;
                            int reduceHitPoint = int.Parse(defenceItemElement.Attribute("ReduceHitPoint")?.Value ?? "0");

                            DefenceItem defenceItem = new DefenceItem(defenceName, reduceHitPoint);
                            creature.DefenceItems.Add(defenceItem);
                        }
                    }

                    world.AddCreature(creature);
                }
            }

            // Indlæs verdens objekter
            var worldObjects = worldElement.Element("WorldObjects")?.Elements("WorldObject");
            if (worldObjects != null)
            {
                foreach (var worldObjectElement in worldObjects)
                {
                    string name = worldObjectElement.Attribute("Name")?.Value;
                    bool lootable = bool.Parse(worldObjectElement.Attribute("Lootable")?.Value ?? "false");
                    bool removable = bool.Parse(worldObjectElement.Attribute("Removable")?.Value ?? "false");

                    WorldObject worldObject = new WorldObject(name, lootable, removable);
                    world.AddWorldObject(worldObject);
                }
            }

            return world;
        }
    }
}
