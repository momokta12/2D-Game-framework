﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandatory2DGameFramework.ICreatureComponent
{
    /// <summary>
    /// Interface der repræsenterer en skabning eller gruppe af skabninger i verdenen.
    /// </summary>
    public interface ICreatureComponent
    {
        /// <summary>
        /// Angriber en given skabning eller gruppe.
        /// </summary>
        /// <param name="target">Målet, der skal angribes.</param>
        void Hit(ICreatureComponent target);

        /// <summary>
        /// Modtager skade fra et angreb.
        /// </summary>
        /// <param name="damage">Mængden af skade, der modtages.</param>
        void ReceiveHit(int damage);

        /// <summary>
        /// Bevæger skabningen eller gruppen til en ny position i verdenen.
        /// </summary>
        /// <param name="deltaX">Ændringen i X-koordinaten.</param>
        /// <param name="deltaY">Ændringen i Y-koordinaten.</param>
        /// <param name="maxX">Den maksimale X-værdi for verdenen.</param>
        /// <param name="maxY">Den maksimale Y-værdi for verdenen.</param>
        void Move(int deltaX, int deltaY, int maxX, int maxY);

        /// <summary>
        /// Viser information om skabningen eller gruppen.
        /// </summary>
        void DisplayInfo();
    }
}
