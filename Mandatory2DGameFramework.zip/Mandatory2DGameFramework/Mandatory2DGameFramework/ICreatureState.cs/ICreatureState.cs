﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandatory2DGameFramework.ICreatureState.cs
{
    /// <summary>
    /// Interface der repræsenterer tilstanden for en skabning.
    /// Bruges til at implementere forskellige adfærdsmønstre, såsom normal, rasende eller svækket.
    /// </summary>
    public interface ICreatureState
    {
        /// <summary>
        /// Håndterer en specifik adfærd for en skabning, afhængigt af dens nuværende tilstand.
        /// </summary>
        /// <param name="creature">Den skabning, hvis tilstand skal håndteres.</param>
        void Handle(Creature creature);

        /// <summary>
        /// Beregner den skade, som en skabning kan påføre, afhængigt af dens nuværende tilstand.
        /// </summary>
        /// <param name="baseDamage">Basis-skadeværdien for skabningen.</param>
        /// <returns>Den totale skade, som skabningen påfører.</returns>
        int CalculateDamage(int baseDamage);
    }
}
