﻿using Mandatory2DGameFramework.model.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandatory2DGameFramework.ICreatureState.cs
{

    /// <summary>
    /// Repræsenterer skabningens svækkede tilstand, hvor den påfører reduceret skade.
    /// </summary>
    public class WeakenedState : ICreatureState
    {
        /// <summary>
        /// Håndterer opførsel for skabningen i svækket tilstand.
        /// Logger, at skabningen er svækket og gør reduceret skade.
        /// </summary>
        /// <param name="creature">Den skabning, der håndteres.</param>
        public void Handle(Creature creature)
        {
            MyLogger.Instance.Log($"{creature.Name} er svækket og gør reduceret skade.");
        }

        /// <summary>
        /// Beregner den skade, skabningen påfører i svækket tilstand.
        /// I svækket tilstand påfører skabningen halvdelen af basisværdien, med et minimum af 1.
        /// </summary>
        /// <param name="baseDamage">Basis-skadeværdien for skabningen.</param>
        /// <returns>Den totale skade, som skabningen påfører i svækket tilstand.</returns>
        public int CalculateDamage(int baseDamage)
        {
            return Math.Max(1, baseDamage / 2); // Reduceret skade, minimum 1
        }
    }
}
