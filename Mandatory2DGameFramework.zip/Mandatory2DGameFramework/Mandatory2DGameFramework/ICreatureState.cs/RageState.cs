﻿using Mandatory2DGameFramework.model.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandatory2DGameFramework.ICreatureState.cs
{
    /// <summary>
    /// Repræsenterer skabningens rasende tilstand, hvor den påfører dobbelt skade.
    /// </summary>
    public class RageState : ICreatureState
    {
        /// <summary>
        /// Håndterer opførsel for skabningen i rasende tilstand.
        /// Logger, at skabningen er rasende og kan gøre dobbelt skade.
        /// </summary>
        /// <param name="creature">Den skabning, der håndteres.</param>
        public void Handle(Creature creature)
        {
            MyLogger.Instance.Log($"{creature.Name} er rasende og gør dobbelt skade!");
        }

        /// <summary>
        /// Beregner den skade, skabningen påfører i rasende tilstand.
        /// I rasende tilstand påfører skabningen dobbelt skade af basisværdien.
        /// </summary>
        /// <param name="baseDamage">Basis-skadeværdien for skabningen.</param>
        /// <returns>Den totale skade, som skabningen påfører i rasende tilstand.</returns>
        public int CalculateDamage(int baseDamage)
        {
            return baseDamage * 2; // Dobbelt skade i rasende tilstand
        }
    }
}
