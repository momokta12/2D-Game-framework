﻿using Mandatory2DGameFramework.model.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandatory2DGameFramework.ICreatureState.cs
{
    /// <summary>
    /// Repræsenterer den normale tilstand for en skabning.
    /// I denne tilstand opfører skabningen sig normalt uden nogen forstærkninger eller svækkelser.
    /// </summary>
    public class NormalState : ICreatureState
    {
        /// <summary>
        /// Håndterer opførsel for skabningen i normal tilstand.
        /// Logger, at skabningen er i sin normale tilstand.
        /// </summary>
        /// <param name="creature">Den skabning, der håndteres.</param>
        public void Handle(Creature creature)
        {
            MyLogger.Instance.Log($"{creature.Name} er i normal tilstand.");
        }

        /// <summary>
        /// Beregner den skade, skabningen påfører i normal tilstand.
        /// I normal tilstand påfører skabningen basis-skaden uden modifikationer.
        /// </summary>
        /// <param name="baseDamage">Basis-skadeværdien for skabningen.</param>
        /// <returns>Den totale skade, som skabningen påfører i normal tilstand.</returns>
        public int CalculateDamage(int baseDamage)
        {
            return baseDamage; // Normal skade
        }
    }
}
