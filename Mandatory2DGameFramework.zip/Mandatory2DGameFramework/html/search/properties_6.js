var searchData=
[
  ['maxx_0',['MaxX',['../class_mandatory2_d_game_framework_1_1worlds_1_1_world.html#a0b1ad1e842a47530036cb945367b8465',1,'Mandatory2DGameFramework::worlds::World']]],
  ['maxy_1',['MaxY',['../class_mandatory2_d_game_framework_1_1worlds_1_1_world.html#a448ca41211652392fcc724b3f06427d7',1,'Mandatory2DGameFramework::worlds::World']]]
];
