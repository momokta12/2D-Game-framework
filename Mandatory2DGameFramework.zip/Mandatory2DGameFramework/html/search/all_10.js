var searchData=
[
  ['y_0',['Y',['../class_creature.html#ad220f7384f869d7a7b2c65fe5838ad0e',1,'Creature']]]
];
