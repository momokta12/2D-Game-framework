var searchData=
[
  ['creatures_0',['Creatures',['../class_mandatory2_d_game_framework_1_1worlds_1_1_world.html#ab551c3b3916692f20697436f53adebec',1,'Mandatory2DGameFramework::worlds::World']]],
  ['currentstate_1',['CurrentState',['../class_creature.html#a11fd7b815b8dda5a0cbb1eaf187d0fe6',1,'Creature']]]
];
