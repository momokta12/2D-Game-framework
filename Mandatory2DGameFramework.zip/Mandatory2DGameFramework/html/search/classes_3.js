var searchData=
[
  ['icreaturecomponent_0',['ICreatureComponent',['../interface_mandatory2_d_game_framework_1_1_i_creature_component_1_1_i_creature_component.html',1,'Mandatory2DGameFramework::ICreatureComponent']]],
  ['icreaturestate_1',['ICreatureState',['../interface_mandatory2_d_game_framework_1_1_i_creature_state_1_1cs_1_1_i_creature_state.html',1,'Mandatory2DGameFramework::ICreatureState::cs']]]
];
