var searchData=
[
  ['knight_0',['Knight',['../namespace_mandatory2_d_game_framework_1_1model_1_1_cretures.html#a53526f279c902339eb4cd8428a576419a8c23b2b86573edf2a5ea482c2ccc1497',1,'Mandatory2DGameFramework::model::Cretures']]]
];
