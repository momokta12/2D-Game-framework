var searchData=
[
  ['creaturetype_0',['CreatureType',['../namespace_mandatory2_d_game_framework_1_1model_1_1_cretures.html#a53526f279c902339eb4cd8428a576419',1,'Mandatory2DGameFramework::model::Cretures']]]
];
