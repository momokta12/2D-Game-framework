var searchData=
[
  ['receivehit_0',['ReceiveHit',['../interface_mandatory2_d_game_framework_1_1_i_creature_component_1_1_i_creature_component.html#ae862a734227c220f314bb7cd8826dec8',1,'Mandatory2DGameFramework.ICreatureComponent.ICreatureComponent.ReceiveHit()'],['../class_creature.html#a6bbfd3038f9c78d396ca29cf87306f3d',1,'Creature.ReceiveHit()']]],
  ['removelistener_1',['RemoveListener',['../class_mandatory2_d_game_framework_1_1model_1_1_logger_1_1_my_logger.html#a35129163b3f3753f288c00cf97862c54',1,'Mandatory2DGameFramework::model::Logger::MyLogger']]]
];
