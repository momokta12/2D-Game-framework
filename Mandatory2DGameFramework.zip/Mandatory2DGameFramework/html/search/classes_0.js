var searchData=
[
  ['attackitem_0',['AttackItem',['../class_mandatory2_d_game_framework_1_1model_1_1attack_1_1_attack_item.html',1,'Mandatory2DGameFramework::model::attack']]]
];
