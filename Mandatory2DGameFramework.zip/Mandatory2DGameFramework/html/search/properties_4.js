var searchData=
[
  ['instance_0',['Instance',['../class_mandatory2_d_game_framework_1_1model_1_1_logger_1_1_my_logger.html#ab3dc98a14a3059de9e7d67b7f45dda7c',1,'Mandatory2DGameFramework::model::Logger::MyLogger']]]
];
