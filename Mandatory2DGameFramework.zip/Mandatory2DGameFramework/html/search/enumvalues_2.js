var searchData=
[
  ['wizard_0',['Wizard',['../namespace_mandatory2_d_game_framework_1_1model_1_1_cretures.html#a53526f279c902339eb4cd8428a576419a5af874093e5efcbaeb4377b84c5f2ec5',1,'Mandatory2DGameFramework::model::Cretures']]]
];
