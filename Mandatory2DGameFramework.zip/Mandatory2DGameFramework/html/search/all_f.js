var searchData=
[
  ['x_0',['X',['../class_creature.html#a2be8a09cc0eb673d1d7fbf340b5bc06c',1,'Creature']]]
];
