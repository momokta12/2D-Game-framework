var searchData=
[
  ['_5finstance_0',['_instance',['../class_mandatory2_d_game_framework_1_1model_1_1_logger_1_1_my_logger.html#a3c2832cae5825baee039b335bfc9f1ec',1,'Mandatory2DGameFramework::model::Logger::MyLogger']]],
  ['_5flisteners_1',['_listeners',['../class_mandatory2_d_game_framework_1_1model_1_1_logger_1_1_my_logger.html#a1e4e61b4a909f733f0b04401d52986a7',1,'Mandatory2DGameFramework::model::Logger::MyLogger']]]
];
