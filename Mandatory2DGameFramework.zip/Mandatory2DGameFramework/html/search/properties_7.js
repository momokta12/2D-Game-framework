var searchData=
[
  ['name_0',['Name',['../class_mandatory2_d_game_framework_1_1worlds_1_1_world_object.html#a22287e4da7ba3627ce0a41cf10dc4a2c',1,'Mandatory2DGameFramework::worlds::WorldObject']]]
];
