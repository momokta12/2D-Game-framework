﻿using System;
using Mandatory2DGameFramework.worlds;
using Mandatory2DGameFramework.XML;
using Mandatory2DGameFramework.model.Cretures;
using Mandatory2DGameFramework.model.Logger;
using Mandatory2DGameFramework.ICreatureState.cs;

namespace GameFrameworkTester
{
    /// <summary>
    /// Testklasse til at demonstrere funktionaliteten i spillets framework.
    /// Tester oprettelse af verden og skabninger, bevægelse, og tilstande.
    /// </summary>
    class Program
{
    /// <summary>
    /// Hovedprogrammet, som demonstrerer brugen af spillets framework.
    /// </summary>
    /// <param name="args">Kommandolinjeparametre.</param>
    static void Main(string[] args)
    {
        // Tilføj en ConsoleTraceListener til loggeren for at vise logbeskeder i konsollen
        MyLogger.Instance.AddListener(new ConsoleTraceListener());

        try
        {
            // Indlæs verden fra XML-filen
            string filePath = @"C:\Users\kasse\OneDrive\Desktop\2DGameframework.xml";
            World world = ConfigReader.LoadWorldFromXml(filePath);
            Console.WriteLine($"Verden er indlæst med dimensionerne ({world.MaxX}, {world.MaxY})");

            // Brug CreatureFactory til at oprette nogle skabninger dynamisk
            Creature dragon = CreatureFactory.CreateCreature(CreatureType.Dragon);
            Creature knight = CreatureFactory.CreateCreature(CreatureType.Knight);
            Creature wizard = CreatureFactory.CreateCreature(CreatureType.Wizard);

            // Tilføj skabningerne til verdenen
            world.AddCreature(dragon);
            world.AddCreature(knight);
            world.AddCreature(wizard);

            // Udskriv skabninger og deres hit points
            foreach (var creature in world.Creatures)
            {
                Console.WriteLine($"Skabning: {creature.Name} med {creature.HitPoint} livspoint.");
            }

            // Flyt skabninger og log deres nye positioner
            Console.WriteLine("\n--- Skabninger bevæger sig ---");
            dragon.Move(1, -1, world.MaxX, world.MaxY); // Flyt dragon til en ny position
            knight.Move(2, 2, world.MaxX, world.MaxY);  // Flyt knight til en ny position
            wizard.Move(-1, 3, world.MaxX, world.MaxY); // Flyt wizard til en ny position

            foreach (var creature in world.Creatures)
            {
                Console.WriteLine($"{creature.Name} er nu på position ({creature.X}, {creature.Y}) med {creature.HitPoint} livspoint.");
            }

            // Lad skabningerne interagere gennem kamp
            Console.WriteLine("\n--- Skabninger interagerer ---");
            dragon.Hit(knight);
            knight.Hit(dragon);
            wizard.Hit(dragon);

            // Ændr tilstand for dragon til RageState og lad den angribe igen
            Console.WriteLine("\n--- Dragon bliver rasende ---");
            dragon.ChangeState(new RageState());
            dragon.Hit(knight);

            // Skift tilstand for knight til WeakenedState og test angreb
            Console.WriteLine("\n--- Knight bliver svækket ---");
            knight.ChangeState(new WeakenedState());
            knight.Hit(dragon);

            // Skift tilbage til NormalState for dragon og lad den angribe wizard
            Console.WriteLine("\n--- Dragon vender tilbage til normal tilstand ---");
            dragon.ChangeState(new NormalState());
            dragon.Hit(wizard);
        }
        catch (Exception ex)
        {
            // Håndter fejl og vis en besked til brugeren
            Console.WriteLine($"Fejl: {ex.Message}");
        }
    }
}
}